# 社区生态 / Community

女娲开源后，社区自发长出了合集、编排工具和主题应用。这一页是官方索引。

> ⚠️ 以下项目由各自作者独立维护，未经本仓库审计，收录不代表背书，使用前自行甄别（尤其注意skill内的指令和脚本）。
> Projects below are independently maintained, unaudited, and listing does not imply endorsement.

## 人物合集索引

| 项目 | 说明 |
|------|------|
| [xixu-me/awesome-persona-distill-skills](https://github.com/xixu-me/awesome-persona-distill-skills) | 人物/关系/纪念场景的persona skill策展合集 |
| [Panmax/awesome-nuwa](https://github.com/Panmax/awesome-nuwa) | 135+人物思维框架合集：哲学家、企业家、科学家全品类 |
| [momozi1996/awesome-ai-persona-skills](https://github.com/momozi1996/awesome-ai-persona-skills) | 100+人格蒸馏合集，含刘慈欣、余华、莫言等中国作家专辑 |
| [tens1x/gefei-perspective-skill](https://github.com/tens1x/gefei-perspective-skill) | 哥飞视角 persona skill：出海工具站、SEO、AdSense、付费流量、定价与独立开发执行框架 |
| [oppenheimor/george-hotz-skills](https://github.com/oppenheimor/george-hotz-skills) | George Hotz/geohot黑客工程思维：硬技术拆解、开源基础设施、AI反hype、最小可运行验证 |

## 多人格编排

| 项目 | 说明 |
|------|------|
| [linzzzzzz/zhuzi-skill](https://github.com/linzzzzzz/zhuzi-skill) | 诸子.skill：让多个人格skill围绕同一问题结构化辩论 |

## 主题应用（女娲方法论的领域迁移）

| 项目 | 说明 |
|------|------|
| [Future3lab/iran-skill](https://github.com/Future3lab/iran-skill) | 119文件的地缘政治分析OS，2500年波斯视角 |
| [JerryZ01/qiuyuan-skill](https://github.com/JerryZ01/qiuyuan-skill) | 球员/教练思维蒸馏系统，女娲流程在体育领域的改编 |

## 收录你的项目

提PR在对应表格加一行即可，门槛见 [CONTRIBUTING.md](CONTRIBUTING.md)：

- 人物skill：自建仓库 + 调研底稿自包含 + 诚实边界 + [保真度评分卡](references/fidelity-scorecard.md) ≥ B
- 合集/工具/编排项目：README说清楚与女娲的关系，无伦理红线问题

一行格式：`| [owner/repo](链接) | 一句话说明 |`
