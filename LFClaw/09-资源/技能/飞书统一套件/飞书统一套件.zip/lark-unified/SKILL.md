---
name: lark-unified
description: "飞书/Lark 统一命令行套件，覆盖消息、文档、电子表格、多维表格、日历、邮件、任务、知识库、幻灯片、会议、OKR、审批和考勤等 18 个业务域。封装官方 lark-cli，提供 200 多个命令、快捷命令/API 命令/原始 API 三层调用方式及无终端交互的初始化流程。适用于收发与搜索消息、创建和编辑文档表格、查询记录、管理日程会议、读取邮件、管理任务和知识库、处理审批及调用飞书开放接口。飞书项目（Meegle）的工作项、需求、缺陷、节点或状态流转、MQL、WBS 请求转交内置子技能。"
description_zh: "飞书/Lark 全能套件：覆盖 18 个业务域；飞书项目（Meegle）工作项按需转交内置子技能。"
description_en: "飞书/Lark 全能套件：消息、文档、表格、多维表格、日历、邮件、任务、知识库、幻灯片等；飞书项目（Meegle）按需转交子技能。"
version: "2.3.0"
allowed-tools: Bash, Read
display_name: "飞书统一套件"
display_name_en: "飞书统一套件"
visibility: "public"
metadata:
  requires:
    bins: ["lark-cli"]
  optionalBins: ["meegle"]
  cliHelp: "lark-cli --help"
  alignedWith: "larksuite/cli v1.0.82; larksuite/meegle-cli v1.0.19"
---

# 飞书统一套件

本技能封装官方 **`lark-cli`**（github.com/larksuite/cli，MIT 许可），覆盖飞书/Lark 的 18 个业务域、200 多个命令，提供无需终端交互的初始化方式，并将官方 26 个技能整合为一个入口。

飞书项目（Meegle）是使用独立命令行工具的另一产品，通过按需加载的子技能处理。操作前先阅读第 0 节，选对产品。

## 0. 产品选择：操作前先判断

飞书协作与飞书项目使用独立程序、独立认证和独立凭据存储，运行时不共享这些资源。选错产品会产生无效授权，甚至返回另一个系统的数据。

| 项目 | 飞书协作（本技能） | 飞书项目 / Meegle（子技能） |
|---|---|---|
| 程序 | `lark-cli` | `meegle` |
| 安装 | 必需，常规环境应已安装 | **仅按需安装**，见 0.3 节 |
| 认证 | `lark-cli auth login`，OAuth 权限范围 | `meegle auth login`，设备码，不使用权限范围模型 |
| 凭据 | `~/.lark-cli/`、系统钥匙串 | `~/.meegle/`、系统钥匙串，**不共享** |
| 入口 | 下文第 1—8 节 | [飞书项目子技能](skills/meegle/SKILL.md) |

### 0.1 判断信号

先根据**关键词**判断产品，再查看对应命令。

**→ 飞书项目 / Meegle（加载子技能）：** 飞书项目、Meegle、Meego、工作项、需求单、缺陷、Bug 单、迭代、排期、工时、节点流转、状态流转、MQL、项目空间、`project_key`、计划表/WBS、度量图表、资源库、交付物，或 `project.feishu.cn`、`meegle.com` 链接。

**→ 飞书协作（继续使用本技能）：** 消息、群聊、文档/docx、电子表格/sheet、多维表格/Base、日历、邮件、知识库/Wiki、云盘/Drive、妙记、会议、OKR、审批、打卡、通讯录。

### 0.2 同名概念：先区分含义

以下常用词在两个产品中含义不同，容易导致错误选择。

| 词语 | 飞书协作 | 飞书项目 / Meegle | 判断方法 |
|---|---|---|---|
| **任务 / task** | 个人待办（`lark-cli task +create`） | 项目空间内的一种工作项类型（`task`），与需求、缺陷并列 | 提到空间、项目、迭代、工作项 ID → Meegle；独立个人提醒 → 飞书任务 |
| **待办 / todo** | `lark-cli task +get-my-tasks` | `meegle mywork todo` | “我的飞书待办”→ 飞书任务；“飞书项目里我的待办”或提及空间 → Meegle |
| **项目 / project** | 通常泛指一项工作 | 正式的空间实体（`project_key`） | “项目空间”“哪个项目下”→ Meegle |
| **评论 / comment** | 文档、表格及云空间评论 | 工作项评论 | 对象为文档/文件 → 飞书协作；对象为工作项 → Meegle |
| **视图 / view** | 多维表格视图（`lark-cli base +view-list`） | 项目视图（`meegle view get`） | 提到 Base、多维表格、`app_token` → 飞书协作；空间、工作项 → Meegle |
| **状态 / 流转** | 不适用 | 节点流、状态流 | 提到流转 → Meegle |
| **排期 / 工时** | 日历事件 | `workhour list-schedule`、节点排期 | 人员或工作项排期 → Meegle；日历会议 → 飞书协作 |

**确实无法区分时向用户询问，不要两个产品都试。**

> 本表和第 5 节业务域表仅覆盖飞书协作。请求无法归入第 5 节时，重新检查 0.1 节是否应使用 Meegle 子技能，不要强行匹配最相近的业务域。

### 0.3 加载 Meegle 子技能

默认不安装 `meegle`，仅在用户明确要求处理飞书项目时安装。

```bash
# 1. 前置检查：一次读取安装、认证状态，返回 JSON 与退出码
STATUS=$(find ~/.workbuddy/skills ./.workbuddy/skills -name meegle_status.py 2>/dev/null | head -1)
python3 "$STATUS"; echo "exit=$?"
```

| 退出码 | 状态 | 处理方式 |
|---|---|---|
| 0 | 就绪 | 阅读子技能后继续 |
| 3 | 未安装 | 按下方第 2 步安装，再检查 |
| 4 | 已安装，未登录 | 按子技能 `auth-guard.md` 执行设备码流程 |
| 5 | 无法解析 | 手动检查 `meegle auth status --format json` |

Meegle **登录后才注册业务命令**。未登录时的 `unknown command "workitem" for "meegle"` 与命令不存在时完全相同，必须使用 `auth status` 区分，不能用业务命令探测登录状态。

```bash
# 2. 只安装程序，两个参数都必须保留
npx -y @lark-project/meegle@latest install --no-skills --no-auth --host <host> --lang zh
```

- **必须带 `--no-skills`**：否则官方向导会执行 `skills add`，将另一份 meegle 技能装入全局技能目录，与内置子技能重复。
- `--no-auth` 将安装和登录分开，使登录可以使用分步设备码流程，避免等待浏览器。
- `npx` **需要 Node.js 18+**。`node --version` 失败或低于 18 时停止，请用户先安装 Node，不尝试绕过。
- 向导会执行 `npm install -g @lark-project/meegle`，写入工作区之外的全局 npm 目录；执行前必须告知用户并取得同意。
- `<host>` 为 `project.feishu.cn`（飞书项目）或 `meegle.com`（国际版）。用户未指定时先询问，避免向错误租户授权。

```bash
# 3. 执行业务命令前先阅读子技能
```

执行任何 Meegle 业务命令前先阅读[子技能](skills/meegle/SKILL.md)。登录使用 `scripts/meegle_setup.py` 封装的分步设备码流程：

```bash
SETUP=$(find ~/.workbuddy/skills ./.workbuddy/skills -name meegle_setup.py 2>/dev/null | head -1)
python3 "$SETUP" --host <host> --print-url-only                  # 第 1 轮：展示链接，然后结束本轮回复
python3 "$SETUP" --resume --device-code <dc> --client-id <cid># 第 2 轮：换取令牌
```

`--resume` 退出码：**0** 已认证；**2** 待授权，可继续轮询；**4** 设备码过期或被拒绝。直接执行 `meegle auth login` 需要交互式终端，在此环境会报 `INTERACTIVE_BROWSER_REQUIRED`。子技能已适配该环境，相对上游的改动见[说明](skills/meegle/NOTICE.md)。

**不要在同一管道混用两套 CLI。** Meegle 的 `work_item_id` 不能交给 `lark-cli`，飞书的 `open_id` 也不是 Meegle 的 `user_key`。跨产品时分别查询身份（`lark-cli contact +search-user` ↔ `meegle user search`）。

## 1. 前置检查：每次操作先执行

> 先完成第 0 节产品选择。本节只检查 `lark-cli`，不说明 `meegle` 是否存在或已授权；飞书项目请求使用 [0.3 节](#03-加载-meegle-子技能)的检查。

不要猜测飞书是否已配置。运行状态脚本，读取 JSON 和退出码。

```bash
# 兼容用户级与项目级技能安装位置
STATUS=$(find ~/.workbuddy/skills ./.workbuddy/skills -name lark_status.py 2>/dev/null | head -1)
python3 "$STATUS" --json; echo "exit=$?"
```

| 退出码 | 状态 | 处理方式 |
|---|---|---|
| 0 | 已配置 | 继续；`userLoggedIn:false` 时仅能使用 `--as bot` |
| 3 | 未安装 | `npx -y @larksuite/cli@latest install`（可能需要数分钟） |
| 4 | 未配置 | 本地工作区运行 `lark_setup.py`；智能体工作区使用 `lark-cli config bind` |
| 5 | 无法解析 | 手动检查 `lark-cli config show` |

需要了解版本、配置文件、机器人/用户身份、接口可达性时，运行内置健康检查。它始终退出 0，必须读取 `ok` 和各检查项的 `status`（`pass`/`warn`/`fail`）。

```bash
lark-cli doctor
```

> `lark-cli config show` 输出驼峰字段 **`appId`**。用 `grep "app_id"` 永远匹配不到，可能每次误判为未配置并重复授权。状态脚本解析 JSON，兼容两种拼写，不要改回文本匹配。

**触发授权提示前，先确定任务所需权限，并检查是否已经授予。** 不要为了方便申请整个业务域，使用户为任务用不到的权限进入管理员审批队列。见[仅申请任务所需权限](#仅申请任务所需权限)。

## 2. 初始化规则

**以下命令需要交互式终端，在此环境可能产生损坏的二维码，不要执行：**

- 不带参数的交互式 `lark-cli config init`
- `lark-cli config init --new`
- 不带参数的交互式 `lark-cli config bind`

**本地工作区：使用无需终端交互的设备授权脚本。**

```bash
SETUP=$(find ~/.workbuddy/skills ./.workbuddy/skills -name lark_setup.py 2>/dev/null | head -1)

python3 "$SETUP"                  # 飞书版，打开浏览器
python3 "$SETUP" --brand lark     # Lark 国际版
python3 "$SETUP" --no-browser  # 只打印链接，不打开浏览器
python3 "$SETUP" --force          # 即使已有配置也重新注册
```

脚本可重复执行：已有 `appId` 时立即退出 0，不会再次授权。

**智能体优先使用分步流程。** 不要在同一轮展示 URL 后阻塞轮询；某些运行环境隐藏中间输出，会使用户看不到链接。

```bash
# 第 1 轮：获取链接后结束回复，等待用户授权
python3 "$SETUP" --print-url-only
# -> {"verification_url": "...", "device_code": "...", "resume_command": "..."}

# 第 2 轮：用户确认已授权后，由智能体执行
python3 "$SETUP" --device-code <device_code>
```

可同时显示二维码。`--output` 仅接受**相对路径**：

```bash
lark-cli auth qrcode "<verification_url>" --output lark-qr.png   # 优先生成 PNG
lark-cli auth qrcode "<verification_url>" --ascii                # ASCII 形式，仅在用户要求时使用
```

将授权 URL 视为完整字符串，不要重新编码或重组查询参数。

**智能体工作区（OpenClaw / Hermes / Lark Channel）：** 设置了 `OPENCLAW_HOME`、`HERMES_HOME` 或 `LARK_CHANNEL` 时，宿主已提供应用，`config init` 会按设计拒绝。改用绑定，并**先向用户确认身份预设**：

```bash
lark-cli config bind --identity bot-only      # 仅机器人，不使用用户身份
lark-cli config bind --identity user-default  # 个人日历、邮件、云盘需要用户身份
```

同一应用修改身份策略使用 `lark-cli config strict-mode`，无需重新绑定。

**已持有凭据时可手动初始化：**

```bash
echo "<APP_SECRET>" | lark-cli config init --app-id <APP_ID> --app-secret-stdin --brand feishu
```

多个应用可保存为具名配置：`lark-cli profile list | add | use <name> | rename | remove`，`use -` 切回上一个配置。单条命令通过 `--profile <name>` 指定配置。

配置位于 `~/.lark-cli/config.json`，可用 `LARKSUITE_CLI_CONFIG_DIR` 覆盖。智能体工作区配置位于 `~/.lark-cli/openclaw/` 或 `~/.lark-cli/hermes/`。密钥保存在系统钥匙串，不写入 JSON。

## 3. 身份认证

```bash
lark-cli auth status --json --verify        # 查看当前身份与令牌有效性
lark-cli whoami                             # 简要显示有效身份
lark-cli auth check --scope "<scope>"       # 退出 0 表示已有权限，1 表示缺失
lark-cli auth scopes                        # 查看应用已持有的权限
lark-cli auth list                          # 列出所有已认证用户
lark-cli auth login --device-code <code>    # 完成分步登录
lark-cli auth logout --json                 # 仅清除本地会话
```

`auth login` **必须**指定权限选择器：`--domain`、`--scope` 或 `--recommend`。多次登录的权限会累积，后续增补不会丢失已经授予的权限。

从 `auth status` 读取 `identity`、`verified`、`identities.user.status`、`identities.user.userName`、`identities.user.tokenStatus`。

### 仅申请任务所需权限

授权页上的每项权限都需要用户同意；许多租户中未经批准的权限会进入管理员审批队列（控制台显示“待发布”）。`--domain base` 会申请约 **40** 项多维表格权限，包括增删改、角色、工作流和高级权限；读取一张表只需 **3** 项。

默认使用 `--scope`，明确列出命令需要的权限：

```bash
# 读取多维表格记录所需的完整权限集合
lark-cli auth login --scope "base:record:read base:table:read base:field:read" --no-wait --json
```

一个 `--scope` 字符串可用空格或逗号分隔。权限拼写错误会在服务端被拒绝，返回 `error.type: "authentication"`，不会静默忽略。

**申请前先查权限：**

1. 各业务域参考文档的“权限”表列出快捷命令对应的精确权限，例如[多维表格](references/lark-base.md)中 `+record-list` 需要 `base:record:read`。
2. 原生 API 命令使用 `lark-cli schema <service>.<resource>.<method>`，读取 `_meta.scopes`。此方式不覆盖 base：其快捷命令不在结构注册表中，`schema base.*` 会报 `Unknown service: base`，应查参考表。
3. 调用仍失败时只申请错误中 `missing_scopes` 列出的权限。

**按影响从小到大扩大权限：**

```bash
# 1. 默认精确申请，符合官方公共技能建议
lark-cli auth login --scope "base:record:read base:table:read base:field:read" --no-wait --json

# 2. 申请整个业务域，但排除破坏性权限
lark-cli auth login --domain base \
  --exclude "base:record:delete,base:table:delete,base:field:delete,base:role:delete" \
  --no-wait --json
```

`--exclude` 从 `--domain` 中扣除权限，结果与 `--scope` 指定的权限取并集。

**`--recommend` 范围很广，并非最小权限选项。** 官方 README 将其称为推荐的自动审批权限，但内置权限目录中有 **310** 项被标为 `recommend: true`，涉及 `im`（51）、`base`（43）、`directory`（33）、`docs`（31），以及审批、日历、通讯录、妙记等，还包括 **13 项删除权限**，如 `base:record:delete`、`base:role:delete`、`base:workflow:delete`、`im:chat:delete`、`space:document:delete`。它比 `--domain base` 申请得更多。仅适合用户知情并同意广泛授权的长期个人配置，不适合只读一张表的任务。

**`--domain all` 仅作最后选项。** 它会申请邮件、日历、考勤、审批、通讯录等全部 23 个域的权限。只有用户明确要求预先授权全部能力时才使用，不因 `missing_scope` 错误直接改用它。

### 常见任务的最小权限

| 任务 | 所需权限 |
|---|---|
| 读取多维表格记录或表 | `base:record:read base:table:read base:field:read` |
| 同时读取视图配置 | 追加 `base:view:read` |
| 写入多维表格记录 | 追加 `base:record:create base:record:update` |
| 读取文档 | `docx:document:readonly` |
| 创建文档 | `docx:document:create` |
| 读取电子表格区域 | `sheets:spreadsheet:read` |
| 写入单元格 | `sheets:spreadsheet:write_only` |
| 查看今日日程 | `calendar:calendar.event:read` |
| 创建日程 | `calendar:calendar.event:create calendar:calendar.event:update` |
| 读取聊天消息 | `im:message:readonly im:chat:read` |
| 以用户身份发消息 | `im:message.send_as_user im:message` |
| 读取邮件 | `mail:user_mailbox.message:readonly` 及地址、主题、正文读取权限 |
| 列举或读取知识库节点 | `wiki:node:retrieve` |
| 读取我的任务 | `task:task:read` |
| 查询同事 | `contact:user:search`，**仅用户身份**；`--as bot` 会退出 2 |
| 按关键词搜索文档 | `search:docs:read` |
| 下载云空间文件 | `drive:file:download drive:drive.metadata:readonly` |

从知识库 URL 解析多维表格或文档还需 `wiki:node:read` / `wiki:node:retrieve`；下载多维表格附件还需 `docs:document.media:download`。

### 重新授权前先检查

`auth check` 检查令牌是否已有所需权限。缺少权限时退出 **1**，输出 `{"ok":false,"missing":[...]}`；`{"error":"not_logged_in"}` 表示没有用户会话。**同一行保存退出码**，管道传给 `head` 或 `jq` 会使 `$?` 变成管道状态。

```bash
OUT=$(lark-cli auth check --scope "base:record:read base:table:read base:field:read" --json); RC=$?
# RC=0：已授权，直接执行命令
# RC=1：读取 OUT.missing，仅申请缺少的权限
```

`auth scopes` 的 `userScopes` 显示应用当前持有的权限；新注册应用通常只有 `offline_access`。

### 与官方 README 的使用顺序差异

官方快速入门以 `lark-cli auth login --recommend` 开始，官方 `lark-shared` 技能将“获取全部权限 → `--domain all`”放在查询表首位，适用于一次性广泛配置。该技能同样明确推荐按具体权限授权：

> `lark-cli auth login --scope "<missing_scope>"   # 按具体 scope 授权（推荐，符合最小权限原则）`

上游快捷命令声明接口接受的最窄权限；`internal/auth/scope.go` 的 `MissingScopes` 使用**精确字符串匹配**，更宽泛的权限名不能替代具体权限。本技能仅调整默认顺序：优先 `--scope`，任务确实覆盖整个域时使用 `--domain`，用户明确要求时才使用 `--recommend` 或 `--domain all`。

### 机器人与用户身份

| 身份 | 参数 | 令牌 | 可访问范围 |
|---|---|---|---|
| 机器人 | `--as bot` | `tenant_access_token` | 应用级资源，只需控制台权限，**无需 `auth login`**；不能查看用户的日历、邮箱和云盘 |
| 用户 | `--as user` | `user_access_token` | 用户自身资源，需要控制台权限及 `auth login` |

`--as` 接受 `user`、`bot`、`auto`，依次按命令参数 → `config default-as` → `auto` 解析。涉及身份时应显式传入 `--as`。

`--as bot` 查询个人日程可能返回空列表，因为机器人读的是自己的空日历。个人资源使用 `--as user`。

### 缺少权限

错误包含 `missing_scopes`、`console_url`、`hint`。

- **机器人身份**：将 `console_url` 原样提供给用户，请其在开发者控制台启用权限；不要为机器人执行 `auth login`。
- **用户身份**：仅申请 `missing_scopes` 列出的权限：

  ```bash
  lark-cli auth login --scope "<scope_1> <scope_2>" --no-wait --json
  ```

不要因为缺少某项权限就扩大到整个域或全部权限。精确追加授权仅增加一次用户确认，过宽授权可能触发管理员审批。

`auth logout` 仅清除本地会话。撤销服务端授权或单项权限，需要用户前往飞书授权管理页面操作。

## 4. 命令调用方式

按优先顺序使用三层命令：

```bash
# 第 1 层：优先快捷命令，提供合理默认值、表格输出和预览
lark-cli im +messages-send --chat-id oc_xxx --text "Hello"

# 第 2 层：生成的 API 命令，与开放接口一一对应
lark-cli calendar calendars list
lark-cli calendar events instance_view --params '{"calendar_id":"primary","start_time":"1700000000","end_time":"1700086400"}'

# 第 3 层：原始 API，可覆盖 2500 多个接口
lark-cli api GET /open-apis/calendar/v4/calendars
lark-cli api POST /open-apis/im/v1/messages --params '{"receive_id_type":"chat_id"}' --data '{...}'
```

调用原始接口前先检查：

```bash
lark-cli schema                        # 列出全部方法
lark-cli schema im.chats.create        # 查询单个方法，使用点分形式
lark-cli schema im chats create        # 等价的空格分隔形式
lark-cli <domain> --help               # 查看业务域命令列表
```

`schema` 返回五个顶层字段：`name`、`description`、`inputSchema`、`outputSchema`、`_meta`。

- **身份限制附在 `description` 文本中**，例如 `创建群。Identity: bot only (tenant_access_token)`，不是独立字段。
- **调用前所需信息位于 `_meta`**：`scopes`、`access_tokens`、`risk`（`read`/`write`/`high-risk-write`）、独立布尔字段 `danger` 和 `doc_url`。

`lark-cli <domain> --help` 是主要命令列表，但不保证完整。部分快捷命令为隐藏注册，仍可调用，例如 `vc +notes`。参考文档中的命令未出现在列表时，先运行 `lark-cli <domain> <shortcut> --help` 再判断是否存在。

第 2、3 层的命令发现、结构输出、原始 API、完整参数表、响应及退出码处理见 [API 参考](references/api_reference.md)。

### 可用参数

输出格式统一使用 **`--format`**，不存在 `--table`、`--csv`、`--yaml`、`--raw` 这些独立参数。

```bash
--format json     # 默认格式，--json 是简写
--format table
--format ndjson   # 适合管道处理
--format csv
--format pretty   # 仅快捷命令支持，原始 API 不接受
```

分页使用 `--page-all`、`--page-limit N`、`--page-delay MS`（默认 200 毫秒）。`--page-limit` 默认 10：快捷命令有效范围为 **1—1000**，传 0 会校验失败；`lark-cli api` 中 **0 表示不限页数**。部分命令还接受 `--page-size` 和 `--page-token`。

常用快捷命令另有 `--as`、`--dry-run`、`--jq`、`--json`、`--yes`（确认高风险写入）、`--output`、`--params` / `--data`（JSON 请求数据）、`--profile`。

脚本可使用以下环境变量避免通知干扰 JSON：

```bash
LARKSUITE_CLI_NO_UPDATE_NOTIFIER=1 LARKSUITE_CLI_NO_SKILLS_NOTIFIER=1 lark-cli auth status --json
```

### JSON 响应：检查 `ok`

成功写入标准输出，退出 0：

```json
{ "ok": true, "identity": "user", "data": { ... }, "meta": { "count": 1 } }
```

失败写入标准错误，退出码非 0：

```json
{ "ok": false, "identity": "user", "error": { "type": "authorization", "subtype": "missing_scope", "code": 99991679, "message": "...", "hint": "...", "missing_scopes": ["..."] } }
```

检查 `ok == true` 或退出码。成功响应**没有顶层 `code`**；`code` 仅在错误对象内，表示上游 OpenAPI 错误码。按旧版 `{"code":0}` 判断会将成功误判为失败，写入时可能重复创建记录，例如重试 `task +create`。

### 退出码 10：等待操作确认

高风险写入未带 `--yes` 时退出 **10**，`error.type` 为 `confirmation`，表示等待确认。向用户展示待执行操作，取得明确确认后再带 `--yes` 重跑，不能自行添加该参数重试。

**身份检查先于操作确认。** 高风险命令身份错误时会退出 **2**（如 `resolved identity "bot" ... only supports: user`），尚未进入确认流程；退出 2 不表示操作安全。先修正身份，随后预期可能退出 10。

```bash
lark-cli apps +openapi-key-delete --app-id <id> --key-id <k>             # 退出 2：身份错误
lark-cli apps +openapi-key-delete --app-id <id> --key-id <k> --as user   # 退出 10：需要确认参数
```

### 必须遵守的规则

- **仅使用相对路径。** `--file`、`--output`、`--output-dir`、`@file` 拒绝绝对路径，可能报 `unsafe output path: --output must be a relative path within the current directory`。部分参数允许 `-`，可通过标准输入传入当前目录外的文件或较大请求数据。
- 不输出 `appSecret` 或访问令牌。
- 写入和删除前确认意图，使用 `--dry-run` 预览。
- 用户未询问版本时忽略 `_notice.update`；`lark-cli update` 会同时更新 CLI 和技能。

## 5. 业务域

`lark-cli --help` 列出 23 个域，以下为常用的 18 个。快捷命令名称来自 CLI 注册表，不确定时用 `lark-cli <domain> --help` 核对，不要猜测。

> 命令域名与参考文件名可能不同：文档命令为复数 **`lark-cli docs`**，参考文件沿用官方技能目录名 `lark-doc.md`。`vc`、`note`、`apps` 也有此差异。

| 业务域 | 功能 | 常用快捷命令 | 参考文档 |
|---|---|---|---|
| **im** | 消息、群聊、搜索、文件、表情回复、卡片、消息流置顶 | `+messages-send` `+messages-reply` `+messages-search` `+messages-mget` `+messages-resources-download` `+chat-list` `+chat-create` `+chat-search` `+chat-update` `+chat-members-list` `+chat-messages-list` `+threads-messages-list` `+flag-create` `+feed-shortcut-create` | [lark-im.md](references/lark-im.md) |
| **docs** | 文档创建、读取、更新、媒体、历史版本、搜索 | `+create` `+fetch` `+update` `+search` `+media-insert` `+media-upload` `+media-download` `+media-preview` `+resource-download` `+resource-update` `+history-list` `+history-revert` | [lark-doc.md](references/lark-doc.md) |
| **drive** | 文件、文件夹、权限、评论、版本与同步 | `+upload` `+download` `+inspect` `+search` `+create-folder` `+move` `+delete` `+import` `+export` `+export-download` `+preview` `+list-comments` `+add-comment` `+member-add` `+member-list` `+version-history` `+permission-get-setting` `+status` `+pull` `+push` `+sync` | [lark-drive.md](references/lark-drive.md) |
| **sheets** | 表格读写、样式、图表、透视表与筛选 | `+workbook-create` `+workbook-info` `+workbook-export` `+sheet-create` `+sheet-copy` `+sheet-info` `+csv-get` `+cells-get` `+cells-set` `+cells-search` `+cells-replace` `+cells-clear` `+range-sort` `+chart-create` `+pivot-create` `+filter-create` `+csv-put` | [lark-sheets.md](references/lark-sheets.md) |
| **base** | 多维表格：记录、字段、视图、仪表盘与角色 | `+url-resolve` `+base-create` `+base-get` `+table-list` `+record-list` `+record-search` `+record-get` `+record-batch-create` `+record-batch-update` `+record-delete` `+record-upsert` `+field-list` `+field-create` `+data-query` `+view-list` `+view-set-filter` `+dashboard-list` `+role-create` | [lark-base.md](references/lark-base.md) |
| **calendar** | 日程、议程、忙闲、会议室与参会回复 | `+agenda` `+create` `+update` `+get` `+search-event` `+freebusy` `+suggestion` `+room-find` `+rsvp` `+meeting` | [lark-calendar.md](references/lark-calendar.md) |
| **task** | 任务、清单、子任务、提醒与负责人 | `+create` `+update` `+get-my-tasks` `+get-related-tasks` `+search` `+complete` `+reopen` `+assign` `+comment` `+reminder` `+followers` `+set-ancestor` `+tasklist-create` `+tasklist-search` `+tasklist-members` `+tasklist-task-add` `+upload-attachment` | [lark-task.md](references/lark-task.md) |
| **mail** | 邮件读取、搜索、发送、回复、转发、草稿、模板与监听 | `+messages` `+message` `+send` `+reply` `+reply-all` `+forward` `+draft-create` `+draft-edit` `+draft-send` `+message-trash` `+message-modify` `+thread` `+triage` `+watch` `+signature` `+share-to-chat` `+lint-html` | [lark-mail.md](references/lark-mail.md) |
| **wiki** | 知识空间、节点树与成员 | `+space-list` `+space-create` `+delete-space` `+node-list` `+node-get` `+node-create` `+node-copy` `+node-delete` `+move` `+move-to-drive` `+member-add` `+member-list` `+member-remove` | [lark-wiki.md](references/lark-wiki.md) |
| **contact** | 用户与机器人查询 | `+search-user` `+get-user` `+search-bot` | [lark-contact.md](references/lark-contact.md) |
| **slides** | 演示文稿、幻灯片页面与截图 | `+create` `+add-slide` `+delete-slide` `+replace-slide` `+replace-pages` `+xml-get` `+screenshot` `+media-upload` `+history-list` | [other-domains.md](references/other-domains.md) |
| **markdown** | 云空间中的原生 Markdown 文件 | `+create` `+fetch` `+patch` `+overwrite` `+diff` | [other-domains.md](references/other-domains.md) |
| **vc** | 会议、录制、纪要与进行中会议控制 | `+search` `+detail` `+recording` `+notes`† `+meeting-events` `+meeting-join` `+meeting-leave` `+meeting-list-active` `+meeting-message-send` | [other-domains.md](references/other-domains.md) |
| **minutes** | 妙记元数据、智能摘要、待办与媒体 | `+search` `+detail` `+summary` `+todo` `+download` `+upload` `+update` `+speaker-replace` `+word-replace` `+apply-permission` | [other-domains.md](references/other-domains.md) |
| **okr** | 目标、关键结果、周期与进展 | `+create` `+batch-create` `+patch` `+cycle-list` `+cycle-detail` `+progress-create` `+progress-list` `+progress-update` `+indicator-update` `+weight` `+reorder` `+upload-image` | [other-domains.md](references/other-domains.md) |
| **approval** | 审批任务、实例与定义 | *无快捷命令。* `approval tasks query` `approval tasks approve` `approval instances create` `approval approvals search` `approval approvals get` | [other-domains.md](references/other-domains.md) |
| **attendance** | 个人打卡记录 | *无快捷命令。* `lark-cli attendance --help`, `lark-cli schema attendance.<resource>.<method>` | [other-domains.md](references/other-domains.md) |
| **apps** | 妙搭应用开发、托管、数据库、日志与发布 | `+init` `+create` `+list` `+get` `+update` `+release-create` `+db-execute` `+db-table-list` `+env-set` `+env-list` `+file-upload` `+log-list` `+trace-list` `+html-publish` `+automation-list` `+role-list` | [other-domains.md](references/other-domains.md) |

此外还支持 **contact**（`+search-user`、`+get-user`、`+search-bot`，见[通讯录](references/lark-contact.md)）、**event**（WebSocket 订阅：`event list`、`event consume <event_key>`、`event status`、`event stop`）、**whiteboard**（`+update`、`+export`、隐藏命令 `+query`†）、**note**（`+detail`、`+transcript`）、**mindnotes**（思维笔记节点）、**application**（绑定应用的自管理）、**approval**、**attendance**。

> † 隐藏注册的命令未在 `--help` 中显示，但可调用，如 `vc +notes`、`whiteboard +query`。
>
> CLI 会拒绝未注册的快捷命令。以下看似合理的命令实际上不存在：`+cells-read`、`+cells-find`、`+sheet-list`、`+workbook-list`、`+workbook-get`、`+get-range`、`+range-get`。应使用 `+csv-get` / `+cells-get`、`+cells-search`、`+workbook-info`（也列出子表）。不确定时查看对应域的帮助。

**本表不包含飞书项目 / Meegle。** 工作项、节点/状态流转、MQL、项目空间、WBS 和工时排期属于独立产品，返回[第 0 节](#0-产品选择操作前先判断)加载子技能，不要用 `lark-cli task` 或 `lark-cli approval` 替代。

## 6. 操作示例

```bash
# 发送消息
lark-cli im +chat-search --keyword "engineering"
lark-cli im +messages-send --chat-id oc_xxx --text "Hello team" --as bot

# 先预览有风险的写入
lark-cli im +messages-send --chat-id oc_xxx --text "test" --dry-run

# 今日日程属于个人资源，必须使用用户身份
lark-cli calendar +agenda --as user

# 从 Markdown 创建文档
lark-cli docs +create --doc-format markdown \
  --content $'<title>Weekly Report</title>\n  # Progress\n- Shipped X'

# 先查看工作簿及子表，再读取区域
# A1 地址加引号，避免感叹号触发 Bash 历史展开
lark-cli sheets +workbook-info --spreadsheet-token <token> --as user
lark-cli sheets +csv-get --spreadsheet-token <token> --range 'Sheet1!A1:D20' --as user

# 分页查询多维表格记录
lark-cli base +record-list --app-token <app_token> --table-id tbl_xxx --page-all --page-limit 5

# 以表格显示所有群聊
lark-cli im +chat-list --as user --format table
```

## 7. 实体标识

用户：`open_id`（`ou_`）、`user_id`、`union_id`、`email`；群聊：`oc_`；消息：`om_`；文档：`document_id` / `doc_token`；文件：`file_token` / `file_key`；多维表格：`app_token` + `tbl_`；电子表格：`spreadsheet_token`；知识库：`space_id` + `node_token`；日历：`calendar_id`（自己可用 `primary`）+ `event_id`；任务：`task_guid`；纪要：`note_id`。

各业务域标识不能互换。知识库节点内嵌文档时，先用 `wiki +node-get` 解析底层 `doc_token`。

## 8. 问题排查

| 现象 | 原因 | 处理方式 |
|---|---|---|
| 简单读取却申请数十项权限，甚至需要管理员审批 | 使用了 `--domain <name>` 或 `--domain all` | 按参考文档“权限”表精确申请；整个 base 约 40 项，读表只需 3 项 |
| 每次初始化都重复授权 | 用 `grep "app_id"` 匹配 `appId` | 使用 `lark_status.py` / `lark_setup.py`，不再匹配 `app_id` |
| 智能体工作区显示 `not configured` | 未绑定宿主应用 | `lark-cli config bind --identity bot-only` |
| `config init` 被拒绝 | 智能体工作区保护 | 使用 `config bind`；仅在用户确实需要第二个应用时使用 `--force-init` |
| 日程或云盘为空 | 机器人读取了自己的资源 | 改用 `--as user` |
| 机器人报 `missing_scope` | 控制台未启用权限 | 将 `console_url` 提供给用户，不执行 `auth login` |
| `unsafe file path` | 使用绝对路径 | 改为当前目录下的相对路径 |
| 退出 10 | 高风险写入等待确认 | 用户确认后带 `--yes` 重跑 |
| 包装脚本认为所有调用都失败 | 检查了 `code == 0` | 检查 `ok == true` 或退出码 |
| 二维码损坏或等待不结束 | 使用交互式 `config init` | 改用 `lark_setup.py` |
| 用户看不到授权 URL | 同一轮展示链接后阻塞轮询 | 先 `--print-url-only` 并结束该轮，用户授权后再执行 `--device-code` |
| Meegle 报 `unknown command "workitem"` | 仅在登录后注册业务命令 | 运行 `meegle auth status --format json`，`authenticated:false` 时先按子技能登录 |
| 用户询问工作项、需求或迭代，但 CLI 无对应域 | 产品选择错误 | 返回[第 0 节](#0-产品选择操作前先判断)，使用 Meegle |
| 安装后出现重复 meegle 技能 | 官方向导执行了 `skills add` | 带 `--no-skills` 重新安装，移除额外添加的全局副本 |

同时更新 CLI 与技能：

```bash
lark-cli update
```
