# 来源与适配

依据用户提供的 WorkBuddy expert-manager 技能包整理。保留原包 Apache License 2.0；LFClaw 版本替换目录、注册和团队工具接口，不代表 WorkBuddy 官方发行。使用本技能需要 LFClaw 专家中心的管理工具。
